<?php
// Heading
$_['heading_title']    = 'Pets';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Pets module!';
$_['text_edit']        = 'Edit Pets Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify pets module!';